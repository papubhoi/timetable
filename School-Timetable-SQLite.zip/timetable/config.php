<?php
declare(strict_types=1);

session_start();

/*
|--------------------------------------------------------------------------
| DATABASE SELECTION
|--------------------------------------------------------------------------
| Change ONLY this line to switch database.
|
| 'mysql'  = Use MySQL/MariaDB
| 'sqlite' = Use SQLite
|
*/

$USE_DATABASE = 'sqlite';   // 'mysql' or 'sqlite'


/*
|--------------------------------------------------------------------------
| DATABASE CONNECTION
|--------------------------------------------------------------------------
*/

try {

    if ($USE_DATABASE === 'mysql') {

        // ================================================================
        // MYSQL / MARIADB
        // ================================================================

        $dbHost = 'localhost';
        $dbName = 'school_timetable';
        $dbUser = 'root';
        $dbPass = '';

        $pdo = new PDO(
            "mysql:host={$dbHost};dbname={$dbName};charset=utf8mb4",
            $dbUser,
            $dbPass,
            [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => false
            ]
        );

    } elseif ($USE_DATABASE === 'sqlite') {

        // ================================================================
        // SQLITE
        // ================================================================

        $dbPath = __DIR__ . '/school_timetable.sqlite';

        if (!file_exists($dbPath)) {
            throw new RuntimeException(
                'SQLite database file not found: ' . $dbPath
            );
        }

        $pdo = new PDO(
            'sqlite:' . $dbPath,
            null,
            null,
            [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => false
            ]
        );

        // Enable foreign-key support in SQLite
        $pdo->exec('PRAGMA foreign_keys = ON');

    } else {

        throw new RuntimeException(
            'Invalid database selection. Use "mysql" or "sqlite".'
        );
    }

} catch (Throwable $e) {

    http_response_code(500);

    exit(
        'Database connection failed. ' .
        ($USE_DATABASE === 'sqlite'
            ? 'Check the SQLite database file.'
            : 'Check the MySQL connection settings.')
    );
}


/*
|--------------------------------------------------------------------------
| HELPER FUNCTIONS
|--------------------------------------------------------------------------
*/

function e(?string $value): string
{
    return htmlspecialchars(
        $value ?? '',
        ENT_QUOTES,
        'UTF-8'
    );
}


function days(): array
{
    return [
        'Monday',
        'Tuesday',
        'Wednesday',
        'Thursday',
        'Friday',
        'Saturday'
    ];
}


function requireAdmin(): void
{
    if (empty($_SESSION['admin_ok'])) {
        header('Location: /timetable/login.php');
        exit;
    }
}


function currentDay(): string
{
    return date('l') === 'Sunday'
        ? 'Monday'
        : date('l');
}
