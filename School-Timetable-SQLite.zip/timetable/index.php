<?php require_once __DIR__.'/config.php'; ?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<title>School Timetable</title>
<link rel="stylesheet" href="css/style.css">
</head>
<body>
<main class="app">
<header class="topbar"><h1>School Timetable</h1><span><?=e(date('d M Y'))?></span></header>
<div class="menu-grid">
<a class="menu-card" href="view/teacher-day.php"><b>📅</b><span>Teacher Timetable</span><small>Day / Week / All Teachers</small></a>
<a class="menu-card danger" href="arrangement/index.php"><b>⚠️</b><span>Arrangement</span><small>Manage absent teachers</small></a>
<a class="menu-card" href="timetable/index.php"><b>🔐</b><span>Enter / Edit Timetable</span><small>Password protected</small></a>
</div>
</main>
</body>
</html>
