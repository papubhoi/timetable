<?php
require_once __DIR__.'/../config.php';
$teachers=$pdo->query("SELECT id,name FROM teachers WHERE active=1 ORDER BY name")->fetchAll();
$day=$_GET['day']??currentDay(); if(!in_array($day,days(),true))$day='Monday';
?>
<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Arrangement</title><link rel="stylesheet" href="../css/style.css"></head>
<body><main class="app"><header class="topbar"><h1>Arrangement</h1><a href="../index.php">Home</a></header>
<form method="get" action="generate.php" class="panel"><label>Day<select name="day"><?php foreach(days() as $d):?><option <?=$d===$day?'selected':''?>><?=$d?></option><?php endforeach;?></select></label>
<h2>Absent Teachers</h2><div class="check-list"><?php foreach($teachers as $t):?><label class="check"><input type="checkbox" name="absent[]" value="<?=$t['id']?>"> <?=e($t['name'])?></label><?php endforeach;?></div>
<button class="btn primary" type="submit">Generate Arrangement</button></form></main></body></html>
