<?php
require_once __DIR__.'/../config.php';
$day=$_GET['day']??currentDay(); if(!in_array($day,days(),true))$day='Monday';
$absent=array_values(array_filter(array_map('intval',$_GET['absent']??[])));
$absentNames=[];
if($absent){$ph=implode(',',array_fill(0,count($absent),'?'));$s=$pdo->prepare("SELECT id,name FROM teachers WHERE id IN ($ph)");$s->execute($absent);foreach($s as $r)$absentNames[$r['id']]=$r['name'];}

$classes=$pdo->query("SELECT class_name FROM classes ORDER BY sort_order")->fetchAll(PDO::FETCH_COLUMN);
$allTeachers=$pdo->query("SELECT id,name FROM teachers WHERE active=1 ORDER BY name")->fetchAll();

$affected=[]; // [class][period] = absent teacher names
if($absent){
 $ph=implode(',',array_fill(0,count($absent),'?'));
 $s=$pdo->prepare("SELECT teacher_id,period,class_name FROM timetable WHERE day=? AND teacher_id IN ($ph) AND class_name IS NOT NULL");
 $s->execute(array_merge([$day],$absent));
 foreach($s as $r)$affected[$r['class_name']][(int)$r['period']][]=$absentNames[$r['teacher_id']]??'Absent';
}
$present=array_filter($allTeachers,fn($t)=>!isset($absentNames[$t['id']]));
$occupied=[];
if($present){
 $ids=array_column($present,'id');$ph=implode(',',array_fill(0,count($ids),'?'));
 $s=$pdo->prepare("SELECT teacher_id,period FROM timetable WHERE day=? AND teacher_id IN ($ph) AND class_name IS NOT NULL");
 $s->execute(array_merge([$day],$ids));
 foreach($s as $r)$occupied[$r['teacher_id']][(int)$r['period']]=true;
}
?>
<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Generated Arrangement</title><link rel="stylesheet" href="../css/style.css"></head>
<body><main class="app"><div class="panel"><h1>Arrangement — <?=e($day)?></h1>
<p><b>Absent:</b> <?=e(implode(', ',array_values($absentNames)) ?: 'None')?></p>


<div class="legend">
    <span class="legend-red">■</span> Needs arrangement
</div>

<div class="arrangement-scroll">
    <table class="arrangement-table">
        <thead>
            <tr>
                <th class="class-header">Class / Period</th>
                <?php for($p=1;$p<=8;$p++): ?>
                    <th><?=$p?></th>
                <?php endfor; ?>
            </tr>
        </thead>

        <tbody>
        <?php foreach($classes as $class): ?>
            <tr>
                <th class="class-name">
                    <?=e($class)?>
                </th>

                <?php for($p=1;$p<=8;$p++): ?>
                    <?php $a = $affected[$class][$p] ?? []; ?>

                    <td
                        class="<?= $a ? 'needs-arrangement' : '' ?>"
                        title="<?=e(implode(', ', $a))?>"
                    >
                        <?= $a ? '⚠️' : '' ?>
                    </td>
                <?php endfor; ?>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
</div>

<?php
$teacherStats = [];

foreach ($present as $t) {
    $free = [];
    $occupiedCount = 0;

    for ($p = 1; $p <= 8; $p++) {
        if (!empty($occupied[$t['id']][$p])) {
            $occupiedCount++;
        } else {
            $free[] = $p;
        }
    }

    $teacherStats[] = [
        'name' => $t['name'],
        'free' => $free,
        'free_count' => count($free),
        'occupied_count' => $occupiedCount
    ];
}

/* More free periods first */
usort($teacherStats, function ($a, $b) {
    return $b['free_count'] <=> $a['free_count'];
});
?>

<div class="table-wrap present-teachers-table">
    <table>
        <thead>
            <tr>
                <th>Teacher Name</th>
                <th>Free Periods</th>
                <th>Occupied</th>
            </tr>
        </thead>

        <tbody>
        <?php foreach ($teacherStats as $teacher): ?>
            <tr>
                <td class="teacher-name-cell">
                    <?=e($teacher['name'])?>
                </td>

                <td class="free-cell">
                    <?=e(implode(', ', $teacher['free']) ?: 'None')?>
                </td>

                <td class="occupied-cell">
                    <?=$teacher['occupied_count']?> / 8
                </td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
</div>

<a href="../index.php" class="home-btn">🏠 Home</a>
