<?php
require_once __DIR__.'/../config.php';
requireAdmin();

$teachers = $pdo->query("SELECT id,name FROM teachers WHERE active=1 ORDER BY name")->fetchAll();
$teacherId = (int)($_GET['teacher_id'] ?? ($teachers[0]['id'] ?? 0));
$day = $_GET['day'] ?? currentDay();
if (!in_array($day, days(), true)) $day = 'Monday';

$selected = [];
if ($teacherId) {
    $stmt = $pdo->prepare("SELECT period,class_name,subject FROM timetable WHERE teacher_id=? AND day=?");
    $stmt->execute([$teacherId,$day]);
    foreach ($stmt as $r) $selected[(int)$r['period']] = $r;
}
?>
<!doctype html><html lang="en"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Enter Timetable</title><link rel="stylesheet" href="../css/style.css"></head>
<body><main class="app">
<header class="topbar"><h1>Enter Timetable</h1><a href="../logout.php">Logout</a></header>
<div class="panel">
<?php if (!$teachers): ?>
<div class="alert">Add a teacher first.</div>
<?php endif; ?>
<form method="post" action="save.php">
<input type="hidden" name="teacher_id" value="<?=e((string)$teacherId)?>">
<div class="two">
<label>Teacher<select name="teacher_select" onchange="location='?teacher_id='+this.value+'&day='+encodeURIComponent(document.querySelector('[name=day]').value)">
<?php foreach ($teachers as $t): ?><option value="<?=$t['id']?>" <?=$t['id']==$teacherId?'selected':''?>><?=e($t['name'])?></option><?php endforeach; ?>
</select></label>
<label>Day<select name="day" onchange="location='?teacher_id=<?=$teacherId?>&day='+encodeURIComponent(this.value)">
<?php foreach (days() as $d): ?><option <?=$d===$day?'selected':''?>><?=$d?></option><?php endforeach; ?>
</select></label>
</div>
<div class="table-wrap"><table class="entry-table"><thead><tr><th>Period</th><th>Class</th><th>Subject</th></tr></thead><tbody>
<?php for($p=1;$p<=8;$p++): $r=$selected[$p]??[]; ?>
<tr><td class="period"><?=$p?></td><td><select name="class_name[<?=$p?>]"><option value="">— Free —</option>
<?php foreach ($pdo->query("SELECT class_name FROM classes ORDER BY sort_order") as $c): ?><option value="<?=e($c['class_name'])?>" <?=($r['class_name']??'')===$c['class_name']?'selected':''?>><?=e($c['class_name'])?></option><?php endforeach; ?>
</select></td><td><input name="subject[<?=$p?>]" value="<?=e($r['subject']??'')?>" placeholder="Subject"></td></tr>
<?php endfor; ?>
</tbody></table></div>
<button class="btn primary" type="submit">Save Timetable</button>
</form>
</div>
<p><a class="back" href="../index.php">← Home</a></p>
</main></body></html>
