<?php
require_once __DIR__.'/../config.php';
requireAdmin();

$teacherId = (int)($_POST['teacher_id'] ?? 0);
$day = (string)($_POST['day'] ?? '');
$classes = $_POST['class_name'] ?? [];
$subjects = $_POST['subject'] ?? [];

if (!$teacherId || !in_array($day, days(), true)) exit('Invalid request.');

$pdo->beginTransaction();
try {
    $del = $pdo->prepare("DELETE FROM timetable WHERE teacher_id=? AND day=?");
    $del->execute([$teacherId,$day]);
    $ins = $pdo->prepare("INSERT INTO timetable (teacher_id,day,period,class_name,subject) VALUES (?,?,?,?,?)");
    for ($p=1;$p<=8;$p++) {
        $class = trim((string)($classes[$p] ?? ''));
        $subject = trim((string)($subjects[$p] ?? ''));
        if ($class !== '') $ins->execute([$teacherId,$day,$p,$class,$subject ?: null]);
    }
    $pdo->commit();
} catch (Throwable $e) {
    $pdo->rollBack(); throw $e;
}
header('Location: index.php?teacher_id='.$teacherId.'&day='.urlencode($day).'&saved=1');
exit;
