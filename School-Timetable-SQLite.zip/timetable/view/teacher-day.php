<?php
require_once __DIR__.'/../config.php';
$teachers=$pdo->query("SELECT id,name FROM teachers WHERE active=1 ORDER BY name")->fetchAll();
$teacherId=(int)($_GET['teacher_id']??($teachers[0]['id']??0));
$day=$_GET['day']??currentDay(); if(!in_array($day,days(),true))$day='Monday';
$stmt=$pdo->prepare("SELECT period,class_name,subject FROM timetable WHERE teacher_id=? AND day=?");
$stmt->execute([$teacherId,$day]);
$rows=[];
foreach($stmt as $r)$rows[(int)$r['period']]=$r;
?>
<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Teacher Timetable</title><link rel="stylesheet" href="../css/style.css"></head>
<body><main class="app"><header class="topbar"><h1>Teacher Timetable</h1><a href="../index.php">Home</a></header>
<div class="panel"><div class="two"><label>Teacher<select onchange="location='?teacher_id='+this.value+'&day='+encodeURIComponent(document.querySelector('[name=day]').value)">
<?php foreach($teachers as $t):?><option value="<?=$t['id']?>" <?=$t['id']==$teacherId?'selected':''?>><?=e($t['name'])?></option><?php endforeach;?></select></label>
<label>Day<select name="day" onchange="location='?teacher_id=<?=$teacherId?>&day='+encodeURIComponent(this.value)"><?php foreach(days() as $d):?><option <?=$d===$day?'selected':''?>><?=$d?></option><?php endforeach;?></select></label></div>
<h2><?=e($day)?></h2><div class="period-list"><?php for($p=1;$p<=8;$p++):$r=$rows[$p]??[];?><div class="period-card"><b><?=$p?></b><span><?=e($r['class_name']??'FREE')?></span><small><?=e($r['subject']??'')?></small></div><?php endfor;?></div>
<div class="quick-links"><a class="btn" href="teacher-week.php?teacher_id=<?=$teacherId?>">Weekly Timetable</a><a class="btn" href="all-teachers.php?day=<?=urlencode($day)?>">All Teachers</a></div>
</div></main></body></html>
