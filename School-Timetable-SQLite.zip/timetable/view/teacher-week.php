<?php
require_once __DIR__.'/../config.php';
$teachers=$pdo->query("SELECT id,name FROM teachers WHERE active=1 ORDER BY name")->fetchAll();
$teacherId=(int)($_GET['teacher_id']??($teachers[0]['id']??0));
$dayOrder = "CASE day
    WHEN 'Monday' THEN 1
    WHEN 'Tuesday' THEN 2
    WHEN 'Wednesday' THEN 3
    WHEN 'Thursday' THEN 4
    WHEN 'Friday' THEN 5
    WHEN 'Saturday' THEN 6
    ELSE 7
END";
$stmt=$pdo->prepare("SELECT day,period,class_name,subject FROM timetable WHERE teacher_id=? ORDER BY $dayOrder, period");
$stmt->execute([$teacherId]); $data=[]; foreach($stmt as $r)$data[$r['day']][(int)$r['period']]=$r;
?>
<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Weekly Timetable</title><link rel="stylesheet" href="../css/style.css"></head>
<body><main class="app"><div class="panel"><h1>Weekly Timetable</h1><label>Teacher<select onchange="location='?teacher_id='+this.value"><?php foreach($teachers as $t):?><option value="<?=$t['id']?>" <?=$t['id']==$teacherId?'selected':''?>><?=e($t['name'])?></option><?php endforeach;?></select></label>
<div class="table-wrap"><table><thead><tr><th>Day</th><?php for($p=1;$p<=8;$p++):?><th><?=$p?></th><?php endfor;?></tr></thead><tbody><?php foreach(days() as $d):?><tr><th><?=$d?></th><?php for($p=1;$p<=8;$p++):$r=$data[$d][$p]??[];?><td><?=e($r['class_name']??'—')?><small><?=e($r['subject']??'')?></small></td><?php endfor;?></tr><?php endforeach;?></tbody></table></div><a class="back" href="teacher-day.php?teacher_id=<?=$teacherId?>">← Day View</a></div></main></body></html>
