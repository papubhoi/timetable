<?php
require_once __DIR__.'/../config.php';
$day=$_GET['day']??currentDay(); if(!in_array($day,days(),true))$day='Monday';
$sql="SELECT t.name,tt.period,tt.class_name,tt.subject FROM teachers t LEFT JOIN timetable tt ON tt.teacher_id=t.id AND tt.day=? WHERE t.active=1 ORDER BY t.id,tt.period";
$s=$pdo->prepare($sql);$s->execute([$day]);$data=[];foreach($s as $r)$data[$r['name']][(int)$r['period']]=$r;
?>
<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>All Teachers</title><link rel="stylesheet" href="../css/style.css"></head>
<body><main class="app"><div class="panel"><h1>All Teachers — <?=e($day)?></h1><label>Day<select onchange="location='?day='+encodeURIComponent(this.value)"><?php foreach(days() as $d):?><option <?=$d===$day?'selected':''?>><?=$d?></option><?php endforeach;?></select></label>
<div class="table-wrap"><table><thead><tr><th>Teacher</th><?php for($p=1;$p<=8;$p++):?><th><?=$p?></th><?php endfor;?></tr></thead><tbody><?php foreach($data as $name=>$periods):?><tr><th><?=e($name)?></th><?php for($p=1;$p<=8;$p++):$r=$periods[$p]??[];?><td><?=e($r['class_name']??'—')?></td><?php endfor;?></tr><?php endforeach;?></tbody></table></div><a class="back" href="../index.php">← Home</a></div></main></body></html>
