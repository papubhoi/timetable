<?php
require_once __DIR__.'/config.php';

if (!empty($_SESSION['admin_ok'])) {
    header('Location: timetable/index.php'); exit;
}
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $password = (string)($_POST['password'] ?? '');
    $stmt = $pdo->prepare("SELECT setting_value FROM settings WHERE setting_key='admin_password'");
    $stmt->execute();
    $saved = $stmt->fetchColumn();
    if ($saved !== false && hash_equals((string)$saved, $password)) {
        $_SESSION['admin_ok'] = true;
        header('Location: timetable/index.php'); exit;
    }
    $error = 'Incorrect password.';
}
?>
<!doctype html><html lang="en"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Admin Login</title><link rel="stylesheet" href="css/style.css"></head>
<body><main class="app narrow">
<div class="panel"><h1>🔐 Admin Access</h1>
<?php if ($error): ?><div class="alert"><?=e($error)?></div><?php endif; ?>
<form method="post">
<label>Password<input type="password" name="password" required autofocus></label>
<button class="btn primary" type="submit">Continue</button>
</form>
<a class="back" href="index.php">← Home</a>
</div></main></body></html>
