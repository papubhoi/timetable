<?php
require_once __DIR__.'/config.php'; requireAdmin();
if ($_SERVER['REQUEST_METHOD']==='POST') {
    $name=trim((string)($_POST['name']??''));
    if($name!=='') {
        if ($USE_DATABASE === 'sqlite') {
            $s = $pdo->prepare("INSERT OR IGNORE INTO teachers(name) VALUES(?)");
        } else {
            $s = $pdo->prepare("INSERT IGNORE INTO teachers(name) VALUES(?)");
        }
        $s->execute([$name]);
    }
}
$teachers=$pdo->query("SELECT * FROM teachers ORDER BY name")->fetchAll();
?>
<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Teachers</title><link rel="stylesheet" href="css/style.css"></head>
<body><main class="app"><div class="panel"><h1>Teachers</h1><form method="post"><label>Teacher name<input name="name" required></label><button class="btn primary">Add Teacher</button></form>
<ul class="simple-list"><?php foreach($teachers as $t): ?><li><?=e($t['name'])?></li><?php endforeach; ?></ul><a class="back" href="index.php">← Home</a></div></main></body></html>
