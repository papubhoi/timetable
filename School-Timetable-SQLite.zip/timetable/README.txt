SCHOOL TIMETABLE - INSTALLATION

1. Create/import the database:
   - Open phpMyAdmin
   - Import school_timetable.sql
   - The SQL creates database `school_timetable`.

2. Put this folder inside XAMPP:
   C:\xampp\htdocs\school_timetable\

3. Edit config.php if your MySQL username/password differs:
   $dbUser = 'root';
   $dbPass = '';

4. Open:
   http://localhost/school_timetable/

5. Default admin password:
   change-me

6. IMPORTANT:
   Change `admin_password` in the `settings` table after import.

7. Add teachers:
   For this first version, open:
   http://localhost/school_timetable/teachers.php
   You must already be logged in as admin.

FEATURES INCLUDED
- Password-protected timetable entry
- 6 school days, 8 periods/day
- VI A through X B, XI and XII
- Teacher day timetable
- Teacher weekly timetable
- All teachers day timetable
- Multiple absent teachers
- Automatic highlighting of affected classes/periods
- Present teacher free/occupied period counts
- Mobile-first UI

ARRANGEMENT LOGIC
A class-period cell is highlighted when at least one selected absent teacher
has that class during that period.

This version does NOT automatically assign a replacement teacher. It shows
present teachers and their free periods so the replacement can be chosen manually.

NEXT UPGRADE
A later version can add an "Assign Teacher" function for each highlighted cell,
with automatic filtering of teachers who are free in that period.
