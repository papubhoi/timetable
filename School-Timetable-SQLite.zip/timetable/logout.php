<?php
require_once __DIR__.'/config.php';
unset($_SESSION['admin_ok']);
header('Location: index.php');
exit;
